import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-access-control',
  templateUrl: './access-control.component.html',
  styleUrls: ['./access-control.component.scss']
})
export class AccessControlComponent {

  searchForm!: FormGroup;

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {

    this.searchForm = this.fb.group({
      role: [''],
      accessType: [null],
      caseCategory: [[]],
      subCategory: [[]]
    });

  }

  accessTypes = [
    {
      name: 'Field Level',
      value: 'No Access'
    },
    {
      name: 'Screen Level',
      value: 'SCREEN_LEVEL'
    }
  ];

  caseCategories = [
    {
      name: 'NRI',
      value: 'NRI'
    },
    {
      name: 'Corporate',
      value: 'Corporate'
    }
  ];

  subCategories = [
    {
      name: 'Address Update',
      value: 'Address Update'
    },
    {
      name: 'Stop Check',
      value: 'Stop Check'
    }
  ];

  allTableData = [

    {
      role: 'Admin',
      accessType: 'FIELD_LEVEL',
      caseCategory: 'NRI',
      subCategory: 'Address Update',
      fieldName: 'Address',
      mask: 'XXXX XXXX XXXX XXXX'
    },

    {
      role: 'Admin',
      accessType: 'FIELD_LEVEL',
      caseCategory: 'NRI',
      subCategory: 'Address Update',
      fieldName: 'Aadhaar Number',
      mask: 'XXXX XXXX XXXX'
    },

    {
      role: 'Admin',
      accessType: 'FIELD_LEVEL',
      caseCategory: 'NRI',
      subCategory: 'Address Update',
      fieldName: 'Account Number',
      mask: 'XXXX XXXX XXXX XXXX'
    },

    {
      role: 'Manager',
      accessType: 'SCREEN_LEVEL',
      caseCategory: 'Corporate',
      subCategory: 'Stop Check',
      fieldName: 'Name',
      mask: 'XXXX XXXXX XXXX'
    },

    {
      role: 'Manager',
      accessType: 'SCREEN_LEVEL',
      caseCategory: 'Corporate',
      subCategory: 'Stop Check',
      fieldName: 'DOB',
      mask: 'XX-XX-XXXX'
    },

    {
      role: 'Manager',
      accessType: 'SCREEN_LEVEL',
      caseCategory: 'Corporate',
      subCategory: 'Stop Check',
      fieldName: 'Phone Number',
      mask: 'XX XXXXX XXXXX'
    }

  ];


  tableData: any[] = [];

  isSearched = false;

  search() {

    this.isSearched = true;

    const formValue = this.searchForm.value;

    this.tableData = this.allTableData.filter((item: any) => {

      const roleMatch =
        !formValue.role ||
        item.role.toLowerCase().includes(formValue.role.toLowerCase());

      const accessTypeMatch =
        !formValue.accessType ||
        item.accessType === formValue.accessType.value;

      const caseCategoryMatch =
        !formValue.caseCategory.length ||
        formValue.caseCategory.some(
          (x: any) => x.value === item.caseCategory
        );

      const subCategoryMatch =
        !formValue.subCategory.length ||
        formValue.subCategory.some(
          (x: any) => x.value === item.subCategory
        );

      return (
        roleMatch &&
        accessTypeMatch &&
        caseCategoryMatch &&
        subCategoryMatch
      );

    });

  }



  clear() {

    this.searchForm.reset();

    this.searchForm.patchValue({
      caseCategory: [],
      subCategory: []
    });

    this.tableData = [];

    this.isSearched = false;

  }



  view(row: any) {

    console.log('View', row);

  }



  edit(row: any) {

    console.log('Edit', row);

  }

}