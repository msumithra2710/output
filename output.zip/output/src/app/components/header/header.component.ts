import { Component } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent {
  categories = [
    { name: 'Category' },

    { name: 'Category 2' },

    { name: 'Category 3' },
  ];
}
